// scripts.js

// Function to toggle dark mode
function themeChange() {
  var element = document.body;
  element.classList.toggle("dark-mode");
}
